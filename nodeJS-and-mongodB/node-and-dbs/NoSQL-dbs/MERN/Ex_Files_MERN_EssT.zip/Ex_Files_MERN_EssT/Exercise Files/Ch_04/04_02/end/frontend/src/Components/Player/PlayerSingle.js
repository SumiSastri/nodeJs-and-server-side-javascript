import React from 'react';

const PlayerSingle = () => {
    return ( <div>
        PlayerSingle
    </div> );
}
 
export default PlayerSingle;