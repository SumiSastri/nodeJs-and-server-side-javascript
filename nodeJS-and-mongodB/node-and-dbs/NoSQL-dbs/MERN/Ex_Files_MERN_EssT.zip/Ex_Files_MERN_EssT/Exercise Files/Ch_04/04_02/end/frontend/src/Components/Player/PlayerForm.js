import React from 'react';

class PlayerForm extends React.Component {
    constructor(props) {
        super(props);
        this.state = {  }
    }
    render() { 
        return ( <div>
            PlayerForm
        </div> );
    }
}
 
export default PlayerForm;