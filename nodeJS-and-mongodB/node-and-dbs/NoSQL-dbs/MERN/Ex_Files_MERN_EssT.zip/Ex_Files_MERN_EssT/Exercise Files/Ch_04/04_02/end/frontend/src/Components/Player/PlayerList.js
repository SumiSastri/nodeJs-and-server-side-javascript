import React from 'react';

const PlayerList = () => {
    return ( <div>
        PlayerList
    </div> );
}
 
export default PlayerList;